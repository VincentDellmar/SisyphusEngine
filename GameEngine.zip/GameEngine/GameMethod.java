
/**
 * Write a description of interface GameMethod here.
 *
 * @author Vincent Dellmar BCHS-2024 (vincent@sunreptiles.com)
 * @version .0.0.1 (4/20/2024)
 */
public interface GameMethod<T>
{
    void call(T args);
}
