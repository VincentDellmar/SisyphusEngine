import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;
import java.awt.*;
import java.util.HashMap;

/**
 * Works with Scene known as "workspace" to render objects in Scene.
 *
 * @author Vincent Dellmar BCHS-2024 (vincent@sunreptiles.com)
 * @version .0.0.1 (4/20/2024)
 */
public class RenderService extends JPanel
{
    protected Scene workspace;
    protected Graphics g;
    public void set_workspace(Scene _workspace){workspace = _workspace;} //Allows changing of workspace.
    
    public void setPanel(int WIDTH, int HEIGHT) {this.setSize(new Dimension(WIDTH, HEIGHT)); this.setPreferredSize(new Dimension(WIDTH, HEIGHT)); this.setDoubleBuffered(true);};
    
    public RenderService(){setPanel(1280, 720);} // Individuals may wish to customize workspace themselves.
    public RenderService(int WIDTH, int HEIGHT){setPanel(WIDTH, HEIGHT);} // Individuals may wish to customize workspace themselves.
    
    public RenderService(Scene _workspace){this.set_workspace(_workspace); setPanel(1280, 720);}
    public RenderService(int WIDTH, int HEIGHT, Scene _workspace){this.set_workspace(_workspace); setPanel(WIDTH, HEIGHT);}

    public void addUserListener(UserInputService listener) {
        this.addKeyListener(listener);
        this.addMouseListener(listener);
    }
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.white);
        g.fillRect(0, 0, this.getSize().width, this.getSize().height);
        
        // Renders Actual Objects
        for (HashMap<String, GameObj> layer : workspace.objects) {
            layer.forEach((name, obj) -> {obj.draw(g);});
        }
        // Renders User Interface.
        for (HashMap<String, UserInterface> layer : workspace.uis) {
            layer.forEach((name, obj) -> {obj.draw(g);});
        }
        
        g.dispose();
    }
    public void update() {repaint();}; // TODO, but renders.
}
