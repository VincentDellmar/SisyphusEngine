import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
/**
 * Allows for detection of keys and mouse actions.
 *
 * @author Vincent Dellmar BCHS-2024 (vincent@sunreptiles.com)
 * @version .0.0.1 (4/20/2024)
 */
public class UserInputService implements KeyListener, MouseListener
{
  @Override
  public void keyTyped(KeyEvent e) {
      
    }
  @Override
  public void keyPressed(KeyEvent e) {
    }
  @Override
  public void keyReleased(KeyEvent e) {
    
    }
    // Mouse Events
  @Override
  public void mouseClicked(MouseEvent e) {
    
    }
  @Override
  public void mousePressed(MouseEvent e) {
      
    }
  @Override
  public void mouseReleased(MouseEvent e) {
      
    }
  @Override
  public void mouseEntered(MouseEvent e) {
      
    }
  @Override
  public void mouseExited(MouseEvent e) {
      
    }
}
