public class Main
{
    public static void main() {
        new Game();
    }
}
