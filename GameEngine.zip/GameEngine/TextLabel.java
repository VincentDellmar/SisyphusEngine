import java.awt.Dimension;
import java.util.HashMap;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;

/**
 * TextLabel, creates a TextLabel, extends UserInterface.
 *
 * @author Vincent Dellmar BCHS-2024 (vincent@sunreptiles.com)
 * @version .0.0.1 (4/20/2024)
 */
public class TextLabel extends UserInterface
{
    //Rendering Data.
    Dimension size; //(width, height) -> (width, height) [used in rendering];
    int position[]; //(0, 0) -> (x_off, y_off) [used in rendering & physics];
    String text;
    Color color = new Color(0, 0, 0); // [used in rendering].
    Font font;
    
    HashMap<String, GameMethod> methods;
    public void createMethods() {
        
    }
    /**
     * Creates a TextLabel based on text (String) and position (int, int)
     */
    public TextLabel(String _text, int positionX, int positionY)
    {
        createMethods();
        position = new int[] {0, 0};
        
        text = _text;
        position[0] = positionX;
        position[1] = positionY;
        
    }
    
    //only edit if you know what you're doing.
    /**
     * Rendering call which executes java based drawing instructions using awt Graphics API.
     */
    public void draw(Graphics g) {
        Color gColor = g.getColor();
        g.setColor(color);
        
        Font gFont = g.getFont();
        if (font != null) {g.setFont(font);} // Font stuff.
        g.drawString(text, position[0], position[1]);
        if (font != null) {g.setFont(gFont);} // Font stuff.
        g.setColor(gColor);
    }
}
