import java.awt.Graphics;
import java.util.HashMap;
import java.awt.Dimension;
import java.awt.Color;
/**
 * Literally any physical object in the game.
 *
 * @author Vincent Dellmar BCHS-2024 (vincent@sunreptiles.com)
 * @version .0.0.1 (4/20/2024)
 */
public class GameObj
{
    void draw(Graphics g) {};
    void physics() {};
    HashMap<String, GameMethod> methods;
}
