import java.util.HashMap;

/**
 * Basic Physics Engine for the game.
 *
 * @author Vincent Dellmar BCHS-2024 (vincent@sunreptiles.com)
 * @version .0.0.1 (4/20/2024)
 */
public class PhysicsService
{
    protected Scene workspace;
    public void set_workspace(Scene _workspace){workspace = _workspace;} //Allows changing of workspace.
    
    public PhysicsService() {} // Individuals may wish to change workspace themselves.
    public PhysicsService(Scene _workspace){this.set_workspace(_workspace);}
    
    public void update() {
        // Physics Actual Objects.
        for (HashMap<String, GameObj> layer : workspace.objects) {
            layer.forEach((name, obj) -> {obj.physics();});
        }
    }; // TODO, but renders.
}
