import java.util.HashMap;
import java.util.ArrayList;

/**
 * Where objects belong.
 *
 * @author Vincent Dellmar BCHS-2024 (vincent@sunreptiles.com)
 * @version .0.0.1 (4/20/2024)
 */
public class Scene
{
    ArrayList<HashMap<String, GameObj>> objects;
    ArrayList<HashMap<String, UserInterface>> uis;
    
    public Scene()
    {
        objects = new ArrayList<HashMap<String, GameObj>>();
        uis = new ArrayList<HashMap<String, UserInterface>>();
        
    }
    public void addObject(String name, GameObj obj) {
        if (objects.size() <= 0) {objects.add(new HashMap<String, GameObj>());} // Fills in empty section of array_list.
        objects.get(0).put(name, obj);
    };
    public void addObject(String name, GameObj obj, int layer) {
        if (objects.size() < layer) {
            for (int i = objects.size(); i <= layer; i++) {objects.add(new HashMap<String, GameObj>());}
        } // Fills in empty section of array_list.
        objects.get(layer).put(name, obj);
    };
    
    public void addUI(String name, UserInterface ui) {
        if (uis.size() <= 0) {uis.add(new HashMap<String, UserInterface>());} // Fills in empty section of array_list.
        uis.get(0).put(name, ui);
    };
    public void addObject(String name, UserInterface ui, int layer) {
        if (objects.size() < layer) {
            for (int i = uis.size(); i <= layer; i++) {uis.add(new HashMap<String, UserInterface>());}
        } // Fills in empty section of array_list.
        uis.get(layer).put(name, ui);
    };
}
