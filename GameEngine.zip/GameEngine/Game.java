import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.util.Random;
import java.awt.Color;

/**
 * What the developer programs.
 *
 * @author Vincent Dellmar BCHS-2024 (vincent@sunreptiles.com)
 * @version .0.0.1 (4/20/2024)
 */
public class Game
{
    public Game()
    {
        JFrame window = new JFrame();
        window.setTitle("NAME_HERE"); // Change to name you want window to display.
        window.setResizable(false); // Change if you want window size to be changeable.
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Scene currentScene = new Scene();
        
        RenderService renderer = new RenderService(1920, 1080, currentScene); // Change window size here.
        PhysicsService physics_solver = new PhysicsService(currentScene); // Does the physics
        
        window.add(renderer);
        
        RunService runner = new RunService(renderer, physics_solver, 60);
        runner.startGameThread();
        
        window.pack(); // Allocates proper memory to the renderer for the window (tech garbo).
        
        window.setLocationRelativeTo(null);
        window.setVisible(true);
        
        // GAME CODE.
        Rectangle r = new Rectangle(new Dimension(200, 100), 1920 / 2, 1090 / 2);
        r.ang_vel = .1;
        r.ang_accel = -.1;
        currentScene.addObject("Box", r);
        
        TextLabel l = new TextLabel("Example", 1920 / 2, 200);
        l.font = new Font("TimesRoman", Font.PLAIN, 50);
        currentScene.addUI("ExampleText", l);
        
        
        // User input
        UserInputService listener = new UserInputService() {
            @Override
            public void mousePressed(MouseEvent e) {
                int cnt = 0;
                Random rng = new Random();
                for (int i = 0; i < 10 + rng.nextInt(10); i++) {
                    cnt++;
                    Color rng_color = new Color(rng.nextInt(255), rng.nextInt(255), rng.nextInt(255));
                    Rectangle rect = new Rectangle(new Dimension(20 + rng.nextInt(20), 20 + rng.nextInt(20)), e.getX(), e.getY());
                    rect.vel[0] = 10 * (5 - rng.nextInt(10));
                    rect.vel[1] = 12 * (-10 - rng.nextInt(5));
                    rect.accel[1] = -19.6;
                    rect.color = rng_color;
                    rect.ang_vel = (50 - rng.nextInt(100)) / 5;
                    currentScene.addObject("Box-" + rng.nextInt((int) Math.pow(2, 16)), rect);
                }
            }
        };
        renderer.addUserListener(listener);
    }
}
