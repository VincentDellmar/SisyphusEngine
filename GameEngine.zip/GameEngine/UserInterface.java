import java.awt.Graphics;
import java.util.HashMap;

/**
 * Literally any ui in the game.
 *
 * @author Vincent Dellmar BCHS-2024 (vincent@sunreptiles.com)
 * @version .0.0.1 (4/20/2024)
 */
public class UserInterface
{
    void draw(Graphics g) {}; 
    HashMap<String, GameMethod> methods;
}
