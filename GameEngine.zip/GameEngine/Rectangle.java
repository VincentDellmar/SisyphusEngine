import java.awt.Dimension;
import java.awt.Graphics;
import java.util.HashMap;
import java.awt.Color;

/**
 * Rectangle, 4 points, extends GameObj.
 *
 * @author Vincent Dellmar BCHS-2024 (vincent@sunreptiles.com)
 * @version .0.0.1 (4/20/2024)
 */
public class Rectangle extends GameObj
{

    //Physics & Rendering Data.
    Dimension size; //(width, height) -> (width, height) [used in rendering];
    double position[]; //(0, 0) -> (x_off, y_off) [used in rendering & physics];
    double angle; // val -> theta rads [used in rendering & physics];
    
    double accel[]; //(0, 1) -> (x_accel, y_accel) [used in physics];
    double vel[]; //(0, 0) -> (x_vel, y_vel) [used in physics];
    
    double ang_accel; //val -> theta_accel rads [used in physics];
    double ang_vel; //val -> theta_vel rads [used in physics];

    long last_time = System.nanoTime();
    Color color = new Color(0, 0, 0); // [used in rendering].
    boolean obeyCollisions = true; // [used in physics].
    
    HashMap<String, GameMethod> methods;
    public void createMethods() {
        
    }
    /**
     * Creates a rectangle based on size (Dimension) and position (double, double)
     */
    public Rectangle(Dimension _size, double positionX, double positionY)
    {
        createMethods();
        position = new double[] {0.0, 0.0};
        accel = new double[] {0.0, 0.0};
        vel = new double[] {0.0, 0.0};
        angle = 0.0;
        ang_accel = 0.0;
        ang_vel = 0.0;
        
        size = _size;
        position[0] = positionX;
        position[1] = positionY;
        
    }
    
    //only edit if you know what you're doing.
    /**
     * Rendering call which executes java based drawing instructions using awt Graphics API.
     */
    public void draw(Graphics g) {
        int[] xPoints = new int[5];
        int[] yPoints = new int[5];
        double adjustedSizeX = size.width / 2.0;
        double adjustedSizeY = size.height / 2.0;
        //Fills tables with points.
        //adjustedSizeX
        //adjustedSizeY
        
        //-adjustedSizeX
        //adjustedSizeY
        
        //-adjustedSizeX
        //-adjustedSizeY
        
        //adjustedSizeX
        //-adjustedSizeY
        
        //adjustedSizeX
        //adjustedSizeY
        
        xPoints[0] = (int)(((adjustedSizeX * Math.cos(angle)) - (adjustedSizeY * Math.sin(angle))) + position[0]);
        yPoints[0] = (int)(((adjustedSizeX * Math.sin(angle)) + (adjustedSizeY * Math.cos(angle))) + position[1]);
        
        xPoints[1] = (int)(((-adjustedSizeX * Math.cos(angle)) - (adjustedSizeY * Math.sin(angle))) + position[0]);
        yPoints[1] = (int)(((-adjustedSizeX * Math.sin(angle)) + (adjustedSizeY * Math.cos(angle))) + position[1]);
        
        xPoints[2] = (int)(((-adjustedSizeX * Math.cos(angle)) - (-adjustedSizeY * Math.sin(angle))) + position[0]);
        yPoints[2] = (int)(((-adjustedSizeX * Math.sin(angle)) + (-adjustedSizeY * Math.cos(angle))) + position[1]);
    
        xPoints[3] = (int)(((adjustedSizeX * Math.cos(angle)) - (-adjustedSizeY * Math.sin(angle))) + position[0]);
        yPoints[3] = (int)(((adjustedSizeX * Math.sin(angle)) + (-adjustedSizeY * Math.cos(angle))) + position[1]);
    
        xPoints[4] = (int)(((adjustedSizeX * Math.cos(angle)) - (adjustedSizeY * Math.sin(angle))) + position[0]);
        yPoints[4] = (int)(((adjustedSizeX * Math.sin(angle)) + (adjustedSizeY * Math.cos(angle))) + position[1]);
        
        Color gColor = g.getColor();
        g.setColor(color);
        g.fillPolygon(xPoints, yPoints, 5);
        g.setColor(gColor);
    }
    /**
     * physics() method provides control over how physics interact with this object.
     */
    public void physics() {
        long time = System.nanoTime();
        double deltaTime = (time - last_time) / 1000000000.0;
        //System.out.println("time nano: " + deltaTime);
        last_time = time;
        //int delta_time = (int) ((time - last_time) / 1000000);
        //double delta_time = (double)(time - last_time) / 1000000000.0;
        //long double d = Duration.between(beginTime, Instant.now());

        vel[0] += accel[0] * deltaTime;
        vel[1] -= accel[1] * deltaTime;
        ang_vel += ang_accel * deltaTime;
                
        position[0] += vel[0] * deltaTime;
        position[1] += vel[1] * deltaTime;
        angle += ang_vel * deltaTime;
    }
}
