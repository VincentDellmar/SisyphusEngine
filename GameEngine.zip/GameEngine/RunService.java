import java.lang.Runnable;
/**
 * This is what RenderService and PhysicsService obey.
 *
 * @author Vincent Dellmar BCHS-2024 (vincent@sunreptiles.com)
 * @version .0.0.1 (4/20/2024)
 */
public class RunService implements Runnable
{
    Thread gameThread;
    protected int framerate = 60; // 1000 / framerate = refreshrate;
    RenderService renderer;
    PhysicsService physics_solver;
    
    public void set_framerate(int _framerate) {framerate = _framerate;} //Allows for changing of the framerate.
    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }
    
    public RunService(RenderService _renderer, PhysicsService _physics_solver)
    {
        renderer = _renderer;
        physics_solver = _physics_solver;
        startGameThread();
    }    
    public RunService(RenderService _renderer, PhysicsService _physics_solver, int _framerate)
    {
        renderer = _renderer;
        physics_solver = _physics_solver;
        set_framerate(_framerate);
        startGameThread();
    }
    
    @Override
    public void run() {
        while (gameThread != null) {
            
            
            
            physics_solver.update();
            renderer.update();
            //Basically enforces framerate.
            try
            {gameThread.sleep(1000 / framerate);}
            catch (InterruptedException ie)
            {ie.printStackTrace();}
        }
    }
}
